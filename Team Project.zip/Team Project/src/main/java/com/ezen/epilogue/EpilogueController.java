package com.ezen.epilogue;

public class EpilogueController {
	
	public String home() {
		return "home";
	}
	
}

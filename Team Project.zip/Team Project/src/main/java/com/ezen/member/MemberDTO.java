package com.ezen.member;

/*
create table member(
mem_no NUMBER(6) PRIMARY KEY,
mem_id VARCHAR2(20),
mem_pw VARCHAR2(20),
mem_name VARCHAR2(12),
mem_nickname VARCHAR2(20),
mem_jumin VARCHAR2(14),
mem_tel VARCHAR2(13),
mem_mail VARCHAR2(40),
mem_postno VARCHAR2(5),
mem_address1 VARCHAR2(100),
mem_address2 VARCHAR2(100));
*/


public class MemberDTO {

}

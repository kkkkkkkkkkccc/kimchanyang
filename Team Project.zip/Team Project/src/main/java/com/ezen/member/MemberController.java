package com.ezen.member;

public class MemberController {
	
}

package com.ezen.notice;

public class NoticeController {
	
	public String notice() {
		return "notice";
	}
	
}
